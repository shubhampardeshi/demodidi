package com.eligible.flag.bean;

import org.springframework.stereotype.Component;

@Component
public class DidiResponseBean {
	private String vin;
	private String dealerCode;
	private String dealerZone;
	private String lop;
	private String InServiceDate;
	private String OpenDate;
    private String responseCode;
    private String responsemessage;
    private String didiEligibilityFlag;
    private String didiMessage;
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public String getDealerCode() {
		return dealerCode;
	}
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}
	public String getDealerZone() {
		return dealerZone;
	}
	public void setDealerZone(String dealerZone) {
		this.dealerZone = dealerZone;
	}
	public String getLop() {
		return lop;
	}
	public void setLop(String lop) {
		this.lop = lop;
	}
	public String getInServiceDate() {
		return InServiceDate;
	}
	public void setInServiceDate(String inServiceDate) {
		this.InServiceDate = inServiceDate;
	}
	public String getOpenDate() {
		return OpenDate;
	}
	public void setOpenDate(String openDate) {
		OpenDate = openDate;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponsemessage() {
		return responsemessage;
	}
	public void setResponsemessage(String responsemessage) {
		this.responsemessage = responsemessage;
	}
	public String getDidiEligibilityFlag() {
		return didiEligibilityFlag;
	}
	public void setDidiEligibilityFlag(String didiEligibilityFlag) {
		this.didiEligibilityFlag = didiEligibilityFlag;
	}
	public String getDidiMessage() {
		return didiMessage;
	}
	public void setDidiMessage(String didiMessage) {
		this.didiMessage = didiMessage;
	}
	@Override
	public String toString() {
		return "DidiResponseBean [vin=" + vin + ", dealerCode=" + dealerCode + ", dealerZone=" + dealerZone + ", lop="
				+ lop + ", InServiceDate=" + InServiceDate + ", OpenDate=" + OpenDate + ", responseCode=" + responseCode
				+ ", responsemessage=" + responsemessage + ", didiEligibilityFlag=" + didiEligibilityFlag
				+ ", didiMessage=" + didiMessage + "]";
	}
	public Object getSuccess() {
		// TODO Auto-generated method stub
		return null;
	}

    
}

 
 

	
    	
	

