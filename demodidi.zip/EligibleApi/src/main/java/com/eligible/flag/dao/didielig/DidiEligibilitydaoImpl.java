package com.eligible.flag.dao.didielig;

import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.eligible.flag.bean.DidiRequestBean;

@Repository
public class DidiEligibilitydaoImpl implements DidiEligibilitydao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<Map<String, Object>> getAllData(DidiRequestBean requestBean) {
		StringBuilder query = new StringBuilder();
		
		query.append("WITH CTE AS (");
		query.append("  SELECT *, ");
		query.append("         CASE WHEN Vin  <> '*' THEN 1 ELSE 0 END + ");
		query.append("         CASE WHEN Market <> '*' THEN 1 ELSE 0 END + ");
		query.append("         CASE WHEN Brand  <> '*' THEN 1 ELSE 0 END + ");
		query.append("         CASE WHEN Model_Year  <> '*' THEN 1 ELSE 0 END + ");
		query.append("         CASE WHEN Body_Model  <> '*' THEN 1 ELSE 0 END + ");
		query.append("         CASE WHEN Engine_SC <> '*' THEN 1 ELSE 0 END + ");
		query.append("         CASE WHEN Transmission_SC  <> '*' THEN 1 ELSE 0 END + ");
		query.append("         CASE WHEN Dealer_Code  <> '*' THEN 1 ELSE 0 END + ");
		query.append("         CASE WHEN Dealer_Zone  <> '*' THEN 1 ELSE 0 END + ");
		query.append("         CASE WHEN Dealer_Language  <> '*' THEN 1 ELSE 0 END + ");
		query.append("         CASE WHEN LOP <> '*' THEN 1 ELSE 0 END + ");
		query.append("         CASE WHEN MIS  <> '*' THEN 1 ELSE 0 END + ");
		query.append("         CASE WHEN Effective_Start_Date  <> '*' THEN 1 ELSE 0 END + ");
        query.append("         CASE WHEN Effective_End_Date   <> '*' THEN 1 ELSE 0 END AS nonEmptyCount ");
		query.append("  FROM YOUR_TABLE");
		query.append(")");
		query.append("SELECT * FROM CTE ");
		query.append("WHERE nonEmptyCount = (");
		query.append("  SELECT MAX(nonEmptyCount) FROM CTE");
		query.append(")");
	
		

		String sql = query.toString();
		
		List<Map<String, Object>> data = jdbcTemplate.query(sql, (rs) -> {
			List<Map<String, Object>> entities = new ArrayList<>();

			ResultSetMetaData metaData = rs.getMetaData();
			int columnCount = metaData.getColumnCount();

			while (rs.next()) {

				Map<String, Object> map = new LinkedHashMap<>();
				for (int i = 1; i <= columnCount; i++) {
					String columnName = metaData.getColumnName(i);
					Object columnValue = rs.getObject(i);
					map.put(columnName, columnValue);

				}

				entities.add(map);
			}
//			System.out.println("---\n" + entities+"\n\n");
			return entities;
		});
		
		return data;
	}

}
