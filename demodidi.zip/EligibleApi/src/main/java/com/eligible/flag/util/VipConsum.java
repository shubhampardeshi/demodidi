package com.eligible.flag.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.boot.configurationprocessor.json.JSONException;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class VipConsum {
	
	
	
	  private static final String API_KEY ="cpSeUxdqaH3bjfGxNtMGp7fSl94bn2t723dI9Z4i";
	  private static final String VIP_PRIVATE_API_URL ="https://0jy7u2ebe7-vpce-0081b0b91b6b3f2b3.execute-api.us-east-1.amazonaws.com/test/getVehicle";
	  private static final String ACCEPT = "application/json"; 
	  private static final String CONTENT_TYPE = "application/json";
	 
	//private static final String X_APP_CHECKSUM = "9658A4F795864FE1E555B5B2650F8285E5FC28B6732DE05831BD703366B41F94";

	RestTemplate restTemplate = new RestTemplate();

	public Map<String, String> getVehicle(String requestVin) {
		String checkSum = ChecksumConsumer.generateCheckSum(requestVin);
		 Map<String, String> extractedData = null;
		// System.out.println(new CommonProperties().getApikey()); 
		try {
			HttpHost proxy = new HttpHost("aiproxy.appl.chrysler.com", 9080);
			RequestConfig requestConfig = RequestConfig.custom().setProxy(proxy).build();

			// Create an HTTP client with proxy settings
			CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).build();

			// Create an HTTP POST request
			HttpPost httpPost = new HttpPost(VIP_PRIVATE_API_URL);

			// Set headers
			httpPost.setHeader("Accept", ACCEPT);
			httpPost.setHeader("Content-Type", CONTENT_TYPE);
			httpPost.setHeader("X-App-Checksum", checkSum);
			httpPost.setHeader("x-api-key", API_KEY);

			// JSON data to be sent in the request body
			String jsonData = "{\n" + "  \"vin\": \"" + requestVin + "\"\n" + "}";

			// Set the JSON data as the request entity
			httpPost.setEntity(new StringEntity(jsonData));

			// Execute the request and get the response
			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity responseEntity = response.getEntity();
			if (responseEntity != null) {
				// Convert the response content to a string
				String responseContent = EntityUtils.toString(responseEntity);

				// Check if the response is successful
				if (isResponseSuccessful(responseContent)) {

					ObjectMapper mapper = new ObjectMapper();
			        JsonNode rootNode = mapper.readTree(responseContent.toString());
			        JsonNode data = rootNode.path("success");
			        
			        extractedData = new HashMap<>(); 
			       
					if (data.toString().equals("true")) {
						JsonNode dataNode = rootNode.path("message").path("data");
						Iterator<Entry<String, JsonNode>> fields = dataNode.fields();

						while (fields.hasNext()) {
							Entry<String, JsonNode> field = fields.next();
							extractedData.put(field.getKey(), field.getValue().toString());
						}
					}
				}
			} else {
				extractedData.put("error", "Response is not successful");
			}

			// Ensure the response is properly closed to release resources
			httpClient.close();
		} catch (Exception e) {
			System.out.println("Exception: " + e);
			/* extractedData.put("error", e.getMessage()); */
		}

		return extractedData;
	}

	// Check if the response message is successful
	private boolean isResponseSuccessful(String responseContent) {
		try {
			JSONObject jsonResponse = new JSONObject(responseContent);
			if (jsonResponse.has("success") && jsonResponse.getBoolean("success")) {
				return true;
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return false;
	}

} 