package com.eligible.flag.service;

import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class YourService {

	private final JdbcTemplate jdbcTemplate;

	public YourService(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<Map<String,String>> getPamScreenData() {
        String sql = "SELECT * FROM VEHICLE_DETAILS_TABLE ";
        List<Map<String,String>> data = jdbcTemplate.query(sql, (rs) -> {
        	List<Map<String,String>> entities = new ArrayList<>();
        	
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (rs.next()) {
                
            	Map<String,String> map = new LinkedHashMap<>();
                for (int i = 1; i <= columnCount; i++) {
                    String columnName = metaData.getColumnName(i);
                    Object columnValue = rs.getObject(i);
                    map.put(columnName, columnValue.toString());

                }

                entities.add(map);
            }

            return entities;
        });

        return data;
    }
	
	
	
}
