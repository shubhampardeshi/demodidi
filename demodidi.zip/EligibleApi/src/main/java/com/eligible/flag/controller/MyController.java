package com.eligible.flag.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.eligible.flag.bean.CommonResponse;
import com.eligible.flag.bean.DidiRequestBean;
import com.eligible.flag.service.YourService;
import com.eligible.flag.service.didielig.DidiEligibilityService;
import com.eligible.flag.util.VipConsum;

@Controller
public class MyController {

    
    
	@Autowired
	private YourService service;

	@Autowired
	private DidiEligibilityService didiEligSertvice;

	@RequestMapping("login")
	public String login() {

		return "login";

	}
	

	@GetMapping("/index")
	public ModelAndView indexPage() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("index");
		return modelAndView;
	}

	@GetMapping("/loadTableData")
	@ResponseBody
	public List<Map<String,String>> loadData() {
		 System.out.println(service.getPamScreenData()); 
		 return service.getPamScreenData(); 

	}

	@PostMapping("/didiEligService")
	public ResponseEntity<CommonResponse> didiEligService(@RequestBody DidiRequestBean requestBean) {
		
		Map<String, String> govparmData =null;
		/* new VipConsum().vipOrSLBService();*/
		CommonResponse commonResponse = null;
		try {
			commonResponse = didiEligSertvice.didiEligService(requestBean);
			return new ResponseEntity<CommonResponse>(commonResponse, HttpStatus.OK);
		} catch (Exception e) {
			// commonResponse.setMassage("NOT SUCCESS"); 
			System.out.println(e);
			return new ResponseEntity<CommonResponse>(commonResponse, HttpStatus.EXPECTATION_FAILED);
		}
	}

}
