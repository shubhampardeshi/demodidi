package com.eligible.flag.service.didielig;

import com.eligible.flag.bean.CommonResponse;
import com.eligible.flag.bean.DidiRequestBean;

public interface DidiEligibilityService {

	public CommonResponse didiEligService(DidiRequestBean requestBean)  throws Exception ;
}
