package com.eligible.flag.dao.didielig;

import java.util.List;
import java.util.Map;

import com.eligible.flag.bean.DidiRequestBean;

public interface DidiEligibilitydao {

	public List<Map<String, Object>> getAllData(DidiRequestBean requestBean);
}
