package com.eligible.flag.util;

import java.security.MessageDigest;

import javax.xml.bind.DatatypeConverter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ChecksumConsumer{

	public static String generateCheckSum(String vinNo) {

		String checkSum = null;
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			String vin = vinNo;
	        JsonNode rootNode = mapper.createObjectNode();
	        ((com.fasterxml.jackson.databind.node.ObjectNode) rootNode).put("vin", vin);
			JsonNode node = rootNode;
			String payload = node.toString();
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			byte[] digest = messageDigest.digest(payload.getBytes());
			checkSum = DatatypeConverter.printHexBinary(digest);
			System.out.println("Checksum is: " + checkSum);
		} catch (Exception e1) {
			System.out.println("ChecksumConsumer > generateCheckSum : "+e1);
		} 
		return checkSum;
	}

}
