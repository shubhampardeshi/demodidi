package com.eligible.flag.service.didielig;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.web.Link;
import org.springframework.stereotype.Service;

import com.eligible.flag.bean.CommonResponse;
import com.eligible.flag.bean.DidiRequestBean;
import com.eligible.flag.bean.DidiResponseBean;
import com.eligible.flag.dao.didielig.DidiEligibilitydao;
import com.eligible.flag.service.YourService;
import com.eligible.flag.util.VipConsum;
import com.eligible.flag.validation.didielig.DidiEligReqInpValidation;

@Service
public class DidiEligibilityServiceImpl implements DidiEligibilityService {

	@Autowired
	private DidiEligReqInpValidation validation;
	@Autowired
	private YourService pamscreen;

	@Autowired
	private DidiEligibilitydao dao;

	@Autowired
	private CommonResponse commonResponse;

	@Override
	public CommonResponse didiEligService(DidiRequestBean requestBean) throws Exception {

		commonResponse.setVin(requestBean.getVin());
		Map<String, String> isValid = validation.serverSideValidation(requestBean);

		if (isValid.isEmpty()) {
			commonResponse.setBasicVIP(this.setDataInResponce(requestBean));
			commonResponse.setMassage("SUCCESS");
		} else {

			commonResponse.setMassage("NOT SUCCESS");
			commonResponse.setBasicVIP(isValid);
		}

		return commonResponse;
	}

	private DidiResponseBean setDataInResponce(DidiRequestBean requestBean) throws ParseException {
		DidiResponseBean didiResponseBean = new DidiResponseBean();
		didiResponseBean.setVin(requestBean.getVin());
		didiResponseBean.setDealerCode(requestBean.getDealerCode());
		didiResponseBean.setLop(requestBean.getLop());
		didiResponseBean.setInServiceDate(requestBean.getInServiceDate());

		if (requestBean.getLop() != null && !requestBean.getLop().isEmpty()) {
			Map<String, String> responceOnLop = validation.getFlagOnLop(requestBean.getLop());
			if (responceOnLop != null && !responceOnLop.isEmpty()) {
				if (responceOnLop.containsKey("eligFlag") && responceOnLop.containsKey("massage")) {
					didiResponseBean.setDidiEligibilityFlag(responceOnLop.get("eligFlag"));
					didiResponseBean.setDidiMessage(responceOnLop.get("massage"));
					didiResponseBean.setResponseCode("1");
					didiResponseBean.setResponsemessage("Not-Success");
				} else {
					didiResponseBean = this.setResponceIfProcessNotEnd(didiResponseBean, requestBean);
				}
			} else {
				didiResponseBean = this.setResponceIfProcessNotEnd(didiResponseBean, requestBean);
			}
		} else {
			didiResponseBean = this.setResponceIfProcessNotEnd(didiResponseBean, requestBean);
		}

		return didiResponseBean;
	}

	private DidiResponseBean setResponceIfProcessNotEnd(DidiResponseBean responseBean, DidiRequestBean requestBean)
			throws ParseException {
		Map<String, String> govparmData = new VipConsum().getVehicle(requestBean.getVin());
		System.out.println("govparmData :" + govparmData);
		govparmData = this.calculateMis(requestBean.getInServiceDate(), govparmData);
		if ((requestBean.getDealerCode() != null && !requestBean.getDealerCode().isEmpty())
				&& (requestBean.getLop() != null && !requestBean.getLop().isEmpty())) {
			govparmData.put("LOP", requestBean.getLop());
			govparmData.put("DEALER", requestBean.getDealerCode());
		}
		// govparmData = xyz(govparmData);
		
		govparmData=updateKey(govparmData);

		System.out.println("VIP service data with MIS calculation:\n " + govparmData);
		Map<String, String> finalEndData = this.compairGovparmDataWithPamScreen(govparmData);

		if (finalEndData != null && finalEndData.size() > 0) {
			responseBean.setDidiEligibilityFlag(finalEndData.get("ELIG_FLAG"));
			responseBean.setDidiMessage(finalEndData.get("MESSAGE"));
			responseBean.setDealerCode(finalEndData.get("DEALER"));
			responseBean.setResponseCode("0");
			responseBean.setResponsemessage("Success");
		} else {
			responseBean.setResponseCode("1");
			responseBean.setResponsemessage("Not-Success");
		}
		/*
		 * List<Map<String, Object>> list = dao.getAllData(requestBean); Map<String,
		 * String> responceData = this.getResponceOnCondition(list); //
		 * System.out.println("a row from we get our final data --:\n" + responceData);
		 * 
		 */

		return responseBean;
	}

	private Map<String, String> calculateMis(String date, Map<String, String> govparmData) throws ParseException {

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date staticDate = dateFormat.parse(date);
		Date currentDate = new Date();

		long differenceInDays = (currentDate.getTime() - staticDate.getTime()) / (24 * 60 * 60 * 1000);
		String mis = Integer.toString((int) (differenceInDays / (30.416 + 0.99)));
		govparmData.put("MIS", mis);
		System.out.println("month in service =" + mis);
		return govparmData;

	}

	private Map<String, String> compairGovparmDataWithPamScreen(Map<String, String> vipserviceData) {

		List<Map<String, String>> pamScreenData = pamscreen.getPamScreenData();

		String pamKey = "";
		String pamVal = "";
		String vipServeKey = "";
		String vipServeVal = "";
		Map<String, String> finalData = new LinkedHashMap<>();
       List<String> matchedKeyList = Arrays.asList("TRANS_SC","ENG_SC","MIS","BODY_MODEL","MODEL_YEAR","BRAND");
   
		outerloop: for (Map<String, String> map : pamScreenData) {
			finalData.clear();
			// pam screen data added
			for (Map.Entry<String, String> entry : map.entrySet()) {
				finalData.put(entry.getKey(), entry.getValue());
			}

			int count = 0;
            int x = 0;
			for (Map.Entry<String, String> entry : map.entrySet()) {
				pamKey = entry.getKey();
				if(pamKey.equals("BRAND")) {
				pamVal = entry.getValue().substring(0,1);
				}else {
					pamVal = entry.getValue();
				}
				// vip service
				for (Map.Entry<String, String> vipServioceData : vipserviceData.entrySet()) {
					vipServeKey = vipServioceData.getKey();
				
					if(vipServeKey.equals("BRAND")) {
						vipServeVal = vipServioceData.getValue().substring(0,1);
						}else {
							vipServeVal = vipServioceData.getValue();
						}
					if (matchedKeyList.contains(vipServeKey)) {
				         x++;
						if ((pamKey.equals(
								vipServeKey)  && (pamVal.equals(vipServeVal) || vipServeVal.isEmpty()))) {
							
							count++;
						}
					}
				}
				
			
			}
			 
			if (count == 6) {
				break outerloop;
			} else {
				
				finalData.clear();
			}

		}
		System.out.println("Pam screen data which is match with VIP Service: \n" + finalData);
		return finalData;
	}

	private Map<String, String> getResponceOnCondition(List<Map<String, Object>> sqlData) {
		List<String> list = new ArrayList<>();
		list.add("ENGINE_SC");
		list.add("TRANSMISSION_SC");
		list.add("BRAND");
		list.add("BODY_MODEL");
		list.add("MODEL_YEAR");
		list.add("DEALER_ZONE");
		list.add("DEALER_CODE");
		list.add("LOP");

		Map<String, String> finalData = new HashMap<>();

		// This loop use to iterate our list of priority column
		outerLoop: for (int i = 0; i < list.size(); i++) {
			String priorityVal = list.get(i);
			// its itorate our fetched table data
			for (Map<String, Object> map : sqlData) {
				int count = 0;
				// set perticular row data in flag on thw bsis of column priority
				for (Map.Entry<String, Object> entry : map.entrySet()) {
					if (entry.getKey() != null && entry.getValue() != null) {
						finalData.put(entry.getKey().toString(), entry.getValue().toString());
					}
				}
				// stop the loop execution on the if any priority column satisfied with
				// condition
				for (Map.Entry<String, Object> entry : map.entrySet()) {

					if (entry.getKey() != null && priorityVal.equals(entry.getKey().toString())) {
						if (entry.getValue() != null && !entry.getValue().toString().equals("*")) {
							count++;
						}
					}
				}
				if (count > 0) {
					break outerLoop;
				}
			}
		}

		return finalData;
	}

	public Map<String, String> updateKey(Map<String, String> govparmData) {
		Map<String,String> listKeys = new LinkedHashMap<>();
		listKeys.put("transmission", "TRANS_SC");
		listKeys.put("engine", "ENG_SC");
		listKeys.put("bodyStyle", "BODY_MODEL");
		listKeys.put("modelYear", "MODEL_YEAR");
		listKeys.put("brand", "BRAND");
		
		Map<String, String> finalData = new LinkedHashMap<>();
		
		for (Map.Entry<String, String> entry : govparmData.entrySet()) {
		  
			if(listKeys.containsKey(entry.getKey())) {
				String value = entry.getValue();
				if(value instanceof String) {
					value = value.replaceAll("\"", "").trim();
					if(value.isEmpty()) {
						value = "";
					}
				}
				finalData.put(listKeys.get(entry.getKey()), value);
			}else {
				finalData.put(entry.getKey(), entry.getValue());
			}
		}
		
		return finalData;
	}

}
