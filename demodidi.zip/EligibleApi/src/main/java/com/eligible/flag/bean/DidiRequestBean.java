package com.eligible.flag.bean;

public class DidiRequestBean {

	private String vin;
	private String dealerMarket;
	private String dealerCode;
	private String dealerZone;
	private String dealerLanguage;
	private String source;
	private String lop;
	private String inServiceDate;
	private String openDate;
	
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public String getDealerMarket() {
		return dealerMarket;
	}
	public void setDealerMarket(String dealerMarket) {
		this.dealerMarket = dealerMarket;
	}
	public String getDealerCode() {
		return dealerCode;
	}
	public void setDealerCode(String dealerCode) {
		this.dealerCode = dealerCode;
	}
	public String getDealerZone() {
		return dealerZone;
	}
	public void setDealerZone(String dealerZone) {
		this.dealerZone = dealerZone;
	}
	public String getDealerLanguage() {
		return dealerLanguage;
	}
	public void setDealerLanguage(String dealerLanguage) {
		this.dealerLanguage = dealerLanguage;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getLop() {
		return lop;
	}
	public void setLop(String lop) {
		this.lop = lop;
	}
	public String getInServiceDate() {
		return inServiceDate;
	}
	public void setInServiceDate(String inServiceDate) {
		this.inServiceDate = inServiceDate;
	}
	public String getOpenDate() {
		return openDate;
	}
	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}
	@Override
	public String toString() {
		return "DidiRequestBean [vin=" + vin + ", dealerMarket=" + dealerMarket + ", dealerCode=" + dealerCode
				+ ", dealerZone=" + dealerZone + ", dealerLanguage=" + dealerLanguage + ", source=" + source + ", lop="
				+ lop + ", inServiceDate=" + inServiceDate + ", ipenDate=" + openDate + "]";
	}
	
}
