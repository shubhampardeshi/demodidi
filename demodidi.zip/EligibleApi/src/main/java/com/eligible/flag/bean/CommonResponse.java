package com.eligible.flag.bean;

import org.springframework.stereotype.Component;

@Component
public class CommonResponse {
 
	private String errorCode;
	private String massage;
	private String vin;
	private Object basicVIP;
	private String sucess;
	
	
	public String getErrorCode() 
	{
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getMassage() {
		return massage;
	}
	public void setMassage(String massage) {
		this.massage = massage;
	}
	public String getVin() {
		return vin;
	}
	public void setVin(String vin) {
		this.vin = vin;
	}
	public Object getBasicVIP() {
		return basicVIP;
	}
	public void setBasicVIP(Object basicVIP) {
		this.basicVIP = basicVIP;
	}
	
	@Override
	public String toString() {
		return "CommonResponse [errorCode=" + errorCode + ", massage=" + massage + ", vin=" + vin + ", basicVIP="
				+ basicVIP + "]";
	}
	public String getSucess() {
		return sucess;
	}
	public void setSucess(String sucess) {
		this.sucess = sucess;
	}
		
	
}
