

DROP TABLE IF EXISTS VEHICLE_DETAILS_TABLE;

CREATE TABLE VEHICLE_DETAILS_TABLE (

 

   MARKET VARCHAR(1) not null,

   BRAND VARCHAR(25) not null,

   MODEL_YEAR VARCHAR(4) not null,

   BODY_MODEL VARCHAR(6) not null,

   ENG_SC VARCHAR(3) not null,

   TRANS_SC VARCHAR(3) not null ,

   DEALER VARCHAR(5) not null,

   ZONE1 varchar(2) not null,

   MIS VARCHAR(2) not null,

   ELIG_FLAG ENUM('Y','N') DEFAULT 'N' ,

   STATUS ENUM('A','D','U') DEFAULT 'A',

   MESSAGE VARCHAR(500),

   EFFECTIVE_START_DATE DATE,

   EFFECTIVE_END_DATE DATE,

   

   LOP1_2 VARCHAR(2) not null,

   LOP3_4 VARCHAR(2) not null,

   LOP5_6 VARCHAR(2) not null,

   LOP7_8 VARCHAR(2) not null,

 

   

   CONSTRAINT VEHICLE_DETAILS_TABLE PRIMARY KEY(MARKET, BRAND, MODEL_YEAR, BODY_MODEL, ENG_SC, TRANS_SC, DEALER, ZONE1, MIS,LOP1_2,LOP3_4,LOP5_6,LOP7_8)

  

);

DROP TABLE IF EXISTS VEHICLE_DETAILS;

CREATE TABLE VEHICLE_DETAILS (
    SR_NO INT AUTO_INCREMENT PRIMARY KEY,
    VIN VARCHAR(100),
    DEALER_CODE INT,
    LOP INT,
    RESPONSE_CODE INT,
    MASSAGE VARCHAR(100),
    DIDI_Eligibility_flag VARCHAR(10),
    DIDI_Message VARCHAR(100)
);

DROP TABLE IF EXISTS your_table;


CREATE TABLE your_table (
    
    Vin VARCHAR(50),
    
    Market VARCHAR(10),

    Brand VARCHAR(25),

    Model_Year VARCHAR(50),

    Body_Model VARCHAR(40),

    Engine_SC VARCHAR(60),

    Transmission_SC VARCHAR(30),

    Dealer_Code VARCHAR(50),

    Dealer_Zone VARCHAR(20),

    Dealer_Language VARCHAR(30),

    LOP VARCHAR(80),

    MIS VARCHAR(50),

    Effective_Start_Date VARCHAR(10),

    Effective_End_Date VARCHAR(10)

);

