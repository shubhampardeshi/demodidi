$(document).ready(function () {
    // Initialize the table sorter
    $("#data-table").tablesorter();

    // Add custom CSS classes for sorting icons
    $(".tablesorter-header").append('<i class="sort-icon"></i>');

    // Handle sorting icons and behavior
    $(".tablesorter-header").on("click", function () {
        // Reset sorting icons
        $(".tablesorter-header").removeClass("sorted-asc sorted-desc");
        $(".sort-icon").removeClass("fa-sort-asc fa-sort-desc");

        // Determine sorting order and update icons
        if ($(this).hasClass("headerSortUp")) {
            $(this).addClass("sorted-asc");
            $(this).find(".sort-icon").addClass("fa-sort-asc");
        } else {
            $(this).addClass("sorted-desc");
            $(this).find(".sort-icon").addClass("fa-sort-desc");
        }
    });
});
